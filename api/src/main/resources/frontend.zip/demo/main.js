(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-demo></app-demo>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");




var AppComponent = /** @class */ (function () {
    function AppComponent(titleService) {
        this.titleService = titleService;
        this.titleService.setTitle(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].version);
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["Title"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _training_training_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./training/training.module */ "./src/app/training/training.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");






var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _training_training_module__WEBPACK_IMPORTED_MODULE_4__["TrainingModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"]
            ],
            providers: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["Title"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/training/_model/Mess.ts":
/*!*****************************************!*\
  !*** ./src/app/training/_model/Mess.ts ***!
  \*****************************************/
/*! exports provided: Mess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Mess", function() { return Mess; });
var Mess = /** @class */ (function () {
    function Mess() {
    }
    return Mess;
}());



/***/ }),

/***/ "./src/app/training/_service/demoservice.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/training/_service/demoservice.service.ts ***!
  \**********************************************************/
/*! exports provided: DemoserviceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoserviceService", function() { return DemoserviceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");




var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
        'Content-Type': 'application/json',
        'x-demo': 'super-header',
        'Access-Control-Allow-Methods': 'POST, GET, PUT, OPTIONS, DELETE',
        'Accept': '*/*'
    })
};
var DemoserviceService = /** @class */ (function () {
    function DemoserviceService(http) {
        this.http = http;
        this.baseUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl;
    }
    DemoserviceService.prototype.add = function () {
        return this.http.post(this.baseUrl + "/add", null);
    };
    DemoserviceService.prototype.getByEnvironment = function (evn) {
        return this.http.get(this.baseUrl + "/get?environment=" + evn);
    };
    DemoserviceService.prototype.getEvmActive = function () {
        return this.http.get(this.baseUrl + "/evmactive", { responseType: 'text' });
    };
    DemoserviceService.prototype.updateMessage = function (message) {
        var body = JSON.stringify(message);
        return this.http.put(this.baseUrl + "/update", body, httpOptions);
    };
    DemoserviceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], DemoserviceService);
    return DemoserviceService;
}());



/***/ }),

/***/ "./src/app/training/demo/demo.component.css":
/*!**************************************************!*\
  !*** ./src/app/training/demo/demo.component.css ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".span-test {\n    font-family: Poppins-Regular;\n    font-size: 15px;\n    color: #808080;\n    line-height: 1.2;\n    text-align: right;\n    position: absolute;\n    top: 14px;\n    left: -105px;\n    width: 200px;\n}\ninput:focus{\n    outline: none;\n}\n.label100 {\n    font-family: Poppins-Regular;\n    font-size: 20px;\n    color: #555555;\n    line-height: 1.2;\n\n    display: block;\n    background: transparent;\n    padding: 10px 100px;\n    padding-right: 0px;\n}\n.form_app {\n    width: 100%;\n    display: flex;\n    flex-wrap: wrap;\n    justify-content: space-between;\n    padding: 10px 88px 57px 190px;\n}\n.wrap-info {\n    width: 100%;\n    position: relative;\n    height: 40px;\n    /*margin-bottom: 26px;*/\n}\n.container {\n    width: 100%;\n    min-height: 100vh;\n    display: flex;\n    flex-wrap: wrap;\n    justify-content: center;\n    align-items: center;\n    padding: 15px;\n    background: transparent;\n    position: relative;\n    z-index: 1;\n}\n.wrap-app {\n    width: 670px;\n    background: #fff;\n    border-radius: 10px;\n    overflow: hidden;\n    position: relative;\n}\n/*[ Title form ]*/\n.form-title {\n    width: 100%;\n    position: relative;\n    z-index: 1;\n    display: flex;\n    flex-wrap: wrap;\n    flex-direction: column;\n    align-items: center;\n    background-repeat: no-repeat;\n    background-size: cover;\n    background-position: center;\n\n    padding: 64px 15px 64px 15px;\n}\n.form-title-1 {\n    font-family: Poppins-Bold;\n    font-size: 20px;\n    color: #fff;\n    text-align: center;\n    padding-bottom: 7px;\n}\n.form-title::before {\n    content: \"\";\n    display: block;\n    position: absolute;\n    z-index: -1;\n    width: 100%;\n    height: 100%;\n    top: 0;\n    left: 0;\n    background-color: rgba(54, 84, 99, 0.7);\n}\n.btn-group {\n    margin-left: auto\n}\n\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdHJhaW5pbmcvZGVtby9kZW1vLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSw0QkFBNEI7SUFDNUIsZUFBZTtJQUNmLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQixTQUFTO0lBQ1QsWUFBWTtJQUNaLFlBQVk7QUFDaEI7QUFDQTtJQUNJLGFBQWE7QUFDakI7QUFDQTtJQUNJLDRCQUE0QjtJQUM1QixlQUFlO0lBQ2YsY0FBYztJQUNkLGdCQUFnQjs7SUFFaEIsY0FBYztJQUNkLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIsa0JBQWtCO0FBQ3RCO0FBRUE7SUFDSSxXQUFXO0lBS1gsYUFBYTtJQUNiLGVBQWU7SUFDZiw4QkFBOEI7SUFDOUIsNkJBQTZCO0FBQ2pDO0FBRUE7SUFDSSxXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWix1QkFBdUI7QUFDM0I7QUFFQTtJQUNJLFdBQVc7SUFDWCxpQkFBaUI7SUFLakIsYUFBYTtJQUNiLGVBQWU7SUFDZix1QkFBdUI7SUFDdkIsbUJBQW1CO0lBQ25CLGFBQWE7SUFDYix1QkFBdUI7SUFDdkIsa0JBQWtCO0lBQ2xCLFVBQVU7QUFDZDtBQUVBO0lBQ0ksWUFBWTtJQUNaLGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtBQUN0QjtBQUVBLGlCQUFpQjtBQUNqQjtJQUNJLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsVUFBVTtJQUtWLGFBQWE7SUFDYixlQUFlO0lBQ2Ysc0JBQXNCO0lBQ3RCLG1CQUFtQjtJQUNuQiw0QkFBNEI7SUFDNUIsc0JBQXNCO0lBQ3RCLDJCQUEyQjs7SUFFM0IsNEJBQTRCO0FBQ2hDO0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsZUFBZTtJQUNmLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsbUJBQW1CO0FBQ3ZCO0FBR0E7SUFDSSxXQUFXO0lBQ1gsY0FBYztJQUNkLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gsV0FBVztJQUNYLFlBQVk7SUFDWixNQUFNO0lBQ04sT0FBTztJQUNQLHVDQUF1QztBQUMzQztBQUVBO0lBQ0k7QUFDSiIsImZpbGUiOiJzcmMvYXBwL3RyYWluaW5nL2RlbW8vZGVtby5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNwYW4tdGVzdCB7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnMtUmVndWxhcjtcbiAgICBmb250LXNpemU6IDE1cHg7XG4gICAgY29sb3I6ICM4MDgwODA7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAxNHB4O1xuICAgIGxlZnQ6IC0xMDVweDtcbiAgICB3aWR0aDogMjAwcHg7XG59XG5pbnB1dDpmb2N1c3tcbiAgICBvdXRsaW5lOiBub25lO1xufVxuLmxhYmVsMTAwIHtcbiAgICBmb250LWZhbWlseTogUG9wcGlucy1SZWd1bGFyO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBjb2xvcjogIzU1NTU1NTtcbiAgICBsaW5lLWhlaWdodDogMS4yO1xuXG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgcGFkZGluZzogMTBweCAxMDBweDtcbiAgICBwYWRkaW5nLXJpZ2h0OiAwcHg7XG59XG5cbi5mb3JtX2FwcCB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgZGlzcGxheTogLXdlYmtpdC1mbGV4O1xuICAgIGRpc3BsYXk6IC1tb3otYm94O1xuICAgIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC13cmFwOiB3cmFwO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBwYWRkaW5nOiAxMHB4IDg4cHggNTdweCAxOTBweDtcbn1cblxuLndyYXAtaW5mbyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGhlaWdodDogNDBweDtcbiAgICAvKm1hcmdpbi1ib3R0b206IDI2cHg7Ki9cbn1cblxuLmNvbnRhaW5lciB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWluLWhlaWdodDogMTAwdmg7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgZGlzcGxheTogLXdlYmtpdC1mbGV4O1xuICAgIGRpc3BsYXk6IC1tb3otYm94O1xuICAgIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC13cmFwOiB3cmFwO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgcGFkZGluZzogMTVweDtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgei1pbmRleDogMTtcbn1cblxuLndyYXAtYXBwIHtcbiAgICB3aWR0aDogNjcwcHg7XG4gICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4vKlsgVGl0bGUgZm9ybSBdKi9cbi5mb3JtLXRpdGxlIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgei1pbmRleDogMTtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWZsZXg7XG4gICAgZGlzcGxheTogLW1vei1ib3g7XG4gICAgZGlzcGxheTogLW1zLWZsZXhib3g7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LXdyYXA6IHdyYXA7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG5cbiAgICBwYWRkaW5nOiA2NHB4IDE1cHggNjRweCAxNXB4O1xufVxuXG4uZm9ybS10aXRsZS0xIHtcbiAgICBmb250LWZhbWlseTogUG9wcGlucy1Cb2xkO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcGFkZGluZy1ib3R0b206IDdweDtcbn1cblxuXG4uZm9ybS10aXRsZTo6YmVmb3JlIHtcbiAgICBjb250ZW50OiBcIlwiO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiAtMTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSg1NCwgODQsIDk5LCAwLjcpO1xufVxuXG4uYnRuLWdyb3VwIHtcbiAgICBtYXJnaW4tbGVmdDogYXV0b1xufVxuXG4iXX0= */"

/***/ }),

/***/ "./src/app/training/demo/demo.component.html":
/*!***************************************************!*\
  !*** ./src/app/training/demo/demo.component.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"wrap-app\">\n        <div class=\"form-title\" style=\"background-image: url(/assets/image/bg-01.jpg)\">\n\t\t\t\t<span class=\"form-title-1\">\n\t\t\t\t\tApplication Profile - Version {{version}}\n\t\t\t\t</span>\n        </div>\n        <form class=\"form_app\">\n\n            <div class=\"wrap-info\">\n                <span class=\"span-test\">Application Name :</span>\n                <label class=\"label100\" type=\"text\" name=\"name\">{{evm?.appName}}</label>\n            </div>\n            <div class=\"wrap-info\">\n                <span class=\"span-test\">Environment :</span>\n                <label class=\"label100\" type=\"text\" name=\"name\">{{evm?.environment}}</label>\n            </div>\n            <div class=\"wrap-info\">\n                <span class=\"span-test\">Database Host :</span>\n                <label class=\"label100\" type=\"text\" name=\"name\">{{hostdata}}</label>\n            </div>\n            <div class=\"wrap-info\">\n                <span class=\"span-test\">Database Name :</span>\n                <label class=\"label100\" type=\"text\" name=\"name\">{{nameDB}}</label>\n            </div>\n            <div class=\"wrap-info\">\n                <span class=\"span-test\">Port Run :</span>\n                <label class=\"label100\" type=\"text\" name=\"name\">{{evm?.portRun}}</label>\n            </div>\n            <div class=\"wrap-info \">\n                <span class=\"span-test\">Message:</span>\n                <input id=\"inputId\" class=\"label100\" type=\"text\" style=\"border: none;width: 450px\" value=\"{{mess}}\"\n                       name=\"message\"\n                       [(ngModel)]=\"messUpdate.message\"\n                       autocomplete=\"off\" (focus)=\"eventForcus()\">\n            </div>\n            <div class=\"btn-group\"  role=\"group\" aria-label=\"Basic example\">\n                <button (click)=\"eventForcus()\" *ngIf=\"check\" class=\"fa fa-pencil btn btn-primary\" title=\"Edit message\"></button>\n                <button *ngIf=\"!check\" class=\"fa fa-check btn btn-success\" (click)=\"updateMessage(messUpdate)\"></button>\n                <button *ngIf=\"!check\" class=\"fa fa-ban btn btn-danger\" (click)=\"cancel()\"></button>\n            </div>\n        </form>\n    </div>\n\n</div>\n\n"

/***/ }),

/***/ "./src/app/training/demo/demo.component.ts":
/*!*************************************************!*\
  !*** ./src/app/training/demo/demo.component.ts ***!
  \*************************************************/
/*! exports provided: DemoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoComponent", function() { return DemoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_demoservice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_service/demoservice.service */ "./src/app/training/_service/demoservice.service.ts");
/* harmony import */ var _model_Mess__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../_model/Mess */ "./src/app/training/_model/Mess.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");





var DemoComponent = /** @class */ (function () {
    function DemoComponent(demoService) {
        this.demoService = demoService;
        this.version = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].version;
        this.mess = '';
        this.check = true;
        this.messUpdate = new _model_Mess__WEBPACK_IMPORTED_MODULE_3__["Mess"]();
    }
    DemoComponent.prototype.ngOnInit = function () {
        this.addEnv();
    };
    DemoComponent.prototype.addEnv = function () {
        var _this = this;
        this.demoService.add().subscribe(function () {
        }, function () {
            _this.getevmActive();
        }, function () { return _this.getevmActive(); });
    };
    DemoComponent.prototype.getevmActive = function () {
        var _this = this;
        this.demoService.getEvmActive().subscribe(function (data) {
            _this.evmActive = data;
            _this.getbyEvm(_this.evmActive);
        }, function (err) {
        });
    };
    DemoComponent.prototype.getbyEvm = function (evmac) {
        var _this = this;
        this.demoService.getByEnvironment(evmac).subscribe(function (data) {
            _this.evm = data;
            _this.hostdata = _this.evm.hostDb.match(/([//]+)(.*)([/])(.*)(?=\?)/)[2];
            _this.nameDB = _this.evm.hostDb.match(/([//]+)(.*)([/])(.*)(?=\?)/)[4];
            _this.mess = _this.evm.mess.message;
            _this.messUpdate.id = _this.evm.mess.id;
        }, function (err) { return console.log(err); });
    };
    DemoComponent.prototype.updateMessage = function (body) {
        var _this = this;
        this.demoService.updateMessage(body).subscribe(function (data) {
            body = data;
            window.location.reload();
            _this.check = true;
        }, function (error) { return console.log(error); });
    };
    DemoComponent.prototype.eventForcus = function () {
        document.getElementById('inputId').focus();
        this.check = false;
    };
    DemoComponent.prototype.cancel = function () {
        this.check = true;
    };
    DemoComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-demo',
            template: __webpack_require__(/*! ./demo.component.html */ "./src/app/training/demo/demo.component.html"),
            styles: [__webpack_require__(/*! ./demo.component.css */ "./src/app/training/demo/demo.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_demoservice_service__WEBPACK_IMPORTED_MODULE_2__["DemoserviceService"]])
    ], DemoComponent);
    return DemoComponent;
}());



/***/ }),

/***/ "./src/app/training/training.module.ts":
/*!*********************************************!*\
  !*** ./src/app/training/training.module.ts ***!
  \*********************************************/
/*! exports provided: TrainingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrainingModule", function() { return TrainingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _demo_demo_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./demo/demo.component */ "./src/app/training/demo/demo.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");





var TrainingModule = /** @class */ (function () {
    function TrainingModule() {
    }
    TrainingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_demo_demo_component__WEBPACK_IMPORTED_MODULE_3__["DemoComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"]
            ],
            exports: [_demo_demo_component__WEBPACK_IMPORTED_MODULE_3__["DemoComponent"]]
        })
    ], TrainingModule);
    return TrainingModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    'apiUrl': 'http://%host_api%:8080/demo',
    'version': '%version%'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/it/Desktop/train/fhm.devops.sources/javasource/training_FE/demo/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map